Title: Final Fantasy IV SNES Record Keeper Sprites Port
Author: T92 
Version: v1.4
Released: 1/8/2023

===============
 Introduction.
===============
This hack changes the battle sprites of Final Fantasy IV SNES to the graphics of 
Final Fantasy Record Keeper.

==========
 Patches.
==========
 Final Fantasy IV Record Keeper Sprites Port v1.4.ips
	The main patch. Should Work with every version of Final Fantasy IV that don't changes sprites.
	Tested with Japan, USA, and Project II Roms.

-----------------------------------------------------------
Optional patches should be applied after the main patch, 
they work on both versions.
-----------------------------------------------------------
 Optional Patches/Cosmic Cecil.ips
	Changes Cecil's sprite for a DS-like sprite.

 Optional Patches/DS-like Rosa.ips
	Changes Rosa's sprite for her alternate sprite resembling the model 
	from the 3D version.

 Optional Patches/Alt DK Cecil.ips
	Changes DK Cecil's sprite for a sprite more similar to the 3D 
	version model drawn by Aerospacecoot35.

 Optional Patches/Alt Golbez.ips
	Changes Golbez's sprite for a new one drawn by Aerospacecoot35.

========
 Bugs.
========
Currently none.
If you found a bug PM the author at RHDN to report it.

==============
 Changelog.
==============
v1.4
 - Added a new optional patches for Golbez and Dark Knight Cecil 
 - Added a new sprite for Paladin Cecil's Cover ability. (Thanks to Aerospacecoot35)
v1.3
 - Added a new pig sprite. (Thanks to mrBrawndo)
v1.2
 - Changed Rydia's hair color to a more yellow one to match her portrait.
 - Added a new sprite for Anna (Thanks to mrBrawndo).
 - Swaped Cecil's cosmic sprite for the classic one.
V1.0
 - First release.
======
 FAQ.
======
Q: "Is this compatible with other hacks that restore the game?"
A: I tested the following hacks and should work fine:
	Project II: Final Fantasy IV
	Final Fantasy IV Namingway Edition

Q: "Is this compatible with the enemy upgrade hack?"
A: Yes.

=================
 Special thanks.
=================
- Everything for FF6Tools wich was used to made this hack.
- Nunzio92, volo and Madruga from The Spriters Resource for the RK sprites.
- Tsushiy for some sprites used in this hack.
- Aerospacecoot35 for alt Cecil and Golbez and for the new Cover sprite.
- mrBrawndo for Anna and Pig's sprite.
- Shiryu64 from Nexus Mods for the sprites of some characters' special animations.
