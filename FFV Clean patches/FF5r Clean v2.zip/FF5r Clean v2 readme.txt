Final Fantasy 5r Clean & Deep Clean
-----------------------------------
Dec 2024: by xJ4cks, Gens, and many others

This project is based on the English translation of "FF5r", crafted by Serity with help from KainStryder and Odym82. My "FF5r Clean" version adds a lot of Quality of Life mechanics, 2 nicer fonts, changes Krile’s battle sprites (to include her hidden Job), and features the astonishing DressCode work by Cubear that shows all Jobs outside of battle.

Gens helped me improve the dialogue font, the Config menu, and crafted optional work that makes this game less difficult and more enjoyable for casual play. These changes are included as optional patches, and also bundled together into a new "FF5r Deep Clean" edition!

The talents of MANY people are leveraged here, and s8fp98fd5k is credited as the author of "FF5r". They already gave themselves a cameo NPC, otherwise I would’ve made them one; many mentors and helpful hackers have their own avatars in Tule, as well as some brave players who’ve actually beaten this hardtype version of FFV…

Two small changes make "FF5r Clean" a bit different from original "FF5r": a new Time spell, and early access to Lix. These can be ignored, or they can provide a slight advantage in this challenging game-– it’s up to you!


Control, Menu, Etc Improvements:
--------------------------------
    ⦾ use Menu button to pass turn in battle
    ⦾ run in towns and dungeons with all jobs (Thief's Dash is even faster)
    ⦾ L & R buttons work in many menus
    ⦾ Re-equip is either "Best" or "Keep", to speed up Job switching
    ⦾ Blue Magic has its own icon, Diamond
    ⦾ Black Magic icon is darker; Float and Blind icons improved
    ⦾ Espers have Black/White/Time icons by effect type
    ⦾ Many Ability & item names match their appearance elsewhere in the FF series
    ⦾ All Jobs and Abilities have descriptions
    ⦾ The 12 items that work with !Mix command are more obvious


Battle Improvements:
--------------------
    ⦾ Berserk doesn’t merely Attack: can work with Jump, Mug, Pierce, Dance, Aim, X-Attack (coded by Inu)
    ⦾ Custom Time spell "Lv Up" gives 1 level in battle per cast (from Tzepish)
    ⦾ Check works as described, showing elemental weakness (from Inu)
    ⦾ Images can stack up to 3 (still 2 per cast or Ability, from Inu)
    ⦾ Force a battle by holding down Start button and walking (only in combat zones, by Cubear)    

    
Graphic Improvements:
---------------------
    ⦾ Menu font enhanced (based on an open source font, by xJ4cks)
    ⦾ Dialogue font changed (as seen in "Tecmo Secret of the Stars", by Gens)
    ⦾ All Jobs are visible on the map (fantastic custom work by Cubear)
    ⦾ Some icons improved (some based on FF6 T-Edition work, by xJ4cks)
    ⦾ Krile looks less “chibi” in battle (completely redrawn sprites, by xJ4cks)
    ⦾ Krile hidden Job made to align with other characters’ hidden Job (by xJ4cks)
    ⦾ Custom title screens (one of many features made possible by noisecross’s FF5e_Text_Editor.exe)


Other Changes:
----------------
    ⦾ Lix can be accessed before gaining the airship (by xJ4cks)
    ⦾ World Map available at game start (from Tzepish)


FF5r Deep Clean Changes:
------------------------
    ⦾ !Steal rate is seriously improved (by Gens)
    ⦾ Learning is always turned on, for all Jobs (by Gens)
    ⦾ Gil, Exp, and ABP increased by 100% from all monsters (by C-Cliff & clymax) 


------------------
Enjoy and please reach out to < alex@j4cks.com > or find me in
FFV Central Discord < https://discord.gg/v7epwcyJfa >
FF4 Ultima Discord < https://discord.gg/PGMASbSnD9 > 
if you need help patching, defeating certain bosses,
or have glitches or typos to report!