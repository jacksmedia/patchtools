FF5r Three Slots - by HatZen08
------------------------------
Created for Final Fantasy 5r by Hatzen08 at the request of Gens.

The rom must be unheadered.

Recommended
Type A: Lets you customize the 1st, 2nd & 3rd Ability slots. Item will always be available.


Developer Mode
Type B: Lets you customize the 2nd, 3rd, and 4th Ability slots. May cause bugs.


Details:
--------
In the original final fantasy 5 game, the three slots patch allowed for all jobs to have three selectable slots for abilities. Unfortunately, it was not compatible with the ff5r mod.

The issue was that the mod changed the allocation of the selected abilities. In the original game the last three slots are changed, leaving the first one
unchanged. Normally it was the fight command. In ff5r the three first slots are changed, leaving the last one unchanged. Normally it is the item command.

This version of the three slots patch was adapted for compatibility for ff5r. It will not work with the original final fantasy 5 game. It must be applied
for the ff5r mod with English translation. 

The rom must be unheadered.

Two versions are available, called A and B. The A version is the recommend one for players. The B version may be useful for hackers.

The A version will allow the first three slots to be customizable for all jobs. It was the designed mod setting for ff5r for the mime/paladin job.

The B version allows the last three slots to be customizable. Normally it leaves the first slot as the fight command. However, because ff5r has a different setting for the jobs default commands the old mime/new paladin job will have a empty command as their first default command. It will generate a bug in specific conditions. If all select-able abilities are passive abilities this will bug the game because there isn't a single choose-able command in the menu. However, this version may be useful for hackers that prefer the original design of the three last customizable slots and can edit the default unchangeable command for all jobs.